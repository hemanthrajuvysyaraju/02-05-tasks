package com.pennant.EmployeeCrud.DTO;

import java.io.Serializable;
import java.util.ArrayList;

public class EmployeeListDTO extends ArrayList<EmployeeDTO> implements Serializable{
	private static final long serialVersionUID = -2050411516871584754L;
}
